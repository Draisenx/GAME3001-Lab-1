using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NewBehaviourScript : MonoBehaviour
{
    [SerializeField] private float moveSpeed;
    [SerializeField] private Transform island;
    [SerializeField] private float loadDistance;
    [SerializeField] private GameObject targetSprite;
    private Vector3 targetPosition = Vector3.zero;

    void Update()
    {
        if (Input.GetMouseButton(0)) //If left mouse button is held.
        {
            //Convert mouse position (screen) to world position.
            targetPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            targetPosition.z = 0f; //Otherwise it takes the z fom the camera's position,
            targetSprite.transform.position = targetPosition;
        }
        //Move the plane towards the targetPosition.
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
        //Snap the plane's rotation to the targetPosition.
        LookAt2D(targetPosition);
        //check distance to island.
        if (Vector3.Distance(transform.position, island.position) <= loadDistance)
        {
            SceneLoader.LoadSceneByIndex(2);
        }
    }

    void LookAt2D(Vector3 target)
    {
        Vector3 lookDirection = target - transform.position;
        float angle = Mathf.Atan2(lookDirection.y, lookDirection.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

    }
}
